import requests
import sqlite3
from flask import Flask, escape, request, jsonify, render_template
from random import randint

app = Flask(__name__)
  
@app.route('/postjson', methods=['POST'])

def postJsonHandler(): #hämtar
    print(f'request.is_json: {request.is_json}')
    content=request.get_json()
    print(f'content: {content}')
    con = sqlite3.connect('weather.db')
    c = con.cursor()
    x = (content['storm'], content['snow'], content['temp'])
    c.execute("INSERT INTO weather (storm, snow, temp) VALUES (?,?,?)", x)
    con.commit()
    con.close()
    return '{"message":"JSON post success"}'
  
@app.route('/')#databas
def fetch(): #hämtar data från databas och returnar till html.
    conn = sqlite3.connect('weather.db')
    c = conn.cursor()
    c.execute("SELECT storm FROM weather")
    value = c.fetchall()
    s = " "
    for v in value:
        s = s+v[0] + " "
        
    c.execute("SELECT snow FROM weather")
    valuex = c.fetchall()
    d = " "
    for x in valuex:
        d = d+x[0] + " "
    
    c.execute("SELECT temp FROM weather")
    values = c.fetchall()
    t = " "
    for y in values:
        t = t+y[0] + " "
    
    return render_template('weather.html', storm=s, snow=d, temp=t)

if __name__ :
    app.debug = True
    app.run(host= '127.0.0.1', port=5000)