import sqlite3
import requests
from flask import Flask, render_template, jsonify, request
from random import randint
import time

def getjson(): #post data
    while True:
        storm = randint(1,100)
        snow= randint(1,100)
        temp = randint(-50,50)
        data_dict = {'storm':storm, 'snow':snow, 'temp':temp}
        x = requests.post('http://127.0.0.1:5000/postjson', json=data_dict)
        print(x.status_code)
        print(x.json())
        print(x.headers)
        time.sleep(10)
getjson()
