import sqlite3
from flask import Flask, escape, request, jsonify, render_template
from random import randint
import requests, time

app = Flask(__name__)
cont = sqlite3.connect('weather.db')
c = cont.cursor()
c.execute("""CREATE TABLE weather(
    storm text,
    snow text,
    temp text
    )""")
cont.commit()
cont.close()

