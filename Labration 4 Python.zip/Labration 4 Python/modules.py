from flask import Flask,render_template,request
import requests,json,http.client,sqlite3

app = Flask(__name__)
@app.route("/")
def index():
    return render_template("index.html")

@app.route('/', methods=['POST'])
def register():
    payment = request.form.get('payment', 'Not set')
    fname = request.form.get('fname', 'Not set')
    lname = request.form.get('lname', 'Not set')
    address = request.form.get('address', 'Not set')
    zipcode = request.form.get('zipcode', 'Not set')
    city = request.form.get('city', 'Not set')
    cell = request.form.get('cell', 'Not set')
    mail = request.form.get('mail', 'Not set')
    passw = request.form.get('password', 'Not set')
    offers = request.form.get('offers', 'Not set')
    mail_format = request.form.get('mail-format', 'Not set')
    comments = request.form.get('comments', 'Not set')
    data_dict = {
        "payment": payment,
        "fname": fname,
        "lname": lname,
        "address": address,
        "zipcode": zipcode,
        "city": city,
        "cell": cell,
        "mail": mail,
        "passw": passw,
        "offers": offers,
        "mail_format": mail_format,
        "comments" : comments
             }

    r = requests.post('http://127.0.0.1:5000/postjson', json=data_dict)
    print(r.status_code)
    return (f"payment : {payment} <br><br> firstname : {fname} <br><br> lastname : {lname} <br><br> address : {address} <br><br> zipcode : {zipcode} <br><br> city : {city} <br><br> cellphone : {cell} <br><br> mail : {mail} <br><br> password : {passw} <br><br> offers : {offers} <br><br> mail format : {mail_format} <br><br> comments : {comments} <br><br>")

if __name__ == "__main__":
    app.run(debug=True)